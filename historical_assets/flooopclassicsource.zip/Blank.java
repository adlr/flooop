class Blank extends Piece {
	Blank(int yy, int xx) {
		y = yy;
		x = xx;
	}
}