class RedX extends Piece {
	RedX(int yy, int xx) {
		y = yy;
		x = xx;
	}
}